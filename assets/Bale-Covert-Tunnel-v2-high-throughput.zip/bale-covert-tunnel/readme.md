# Bale Covert Tunnel


To fill later


## Installing

Install Python3, Python3-pip and Python3-venv

Alpine Linux:
```
apk add python3 py3-virtualenv py3-pip
```

Debian:
```
apt update && apt install python3 python3-pip python3-venv -y
```

Create a venv

```
python3 -m venv venv
```

Activate venv

```
source venv/bin/activate
```

Install requirments

```
pip3 install python-bale-bot zstandard
```

## Configuration

There are two types of configuration, one is inside the `config.py` file and the other is in the `server.py` or `client.py` depending on which you're using

### config.py

The config.py contains the following:

|Field Name|Value|
|---|---|
|BOT_A_TOKEN|Server's API Token|
|BOT_B_TOKEN|Cleint's API Token|
|SHARED_CHAT_ID|Chat ID of the channel which both bots are admin of|
|CHUNK_SIZE|Maximum size of each chunk to be sent as text message (The maximum is 1024 * 3)|
|LOCAL_LISTEN_HOST|What address the client should listen on|
|LOCAL_LISTEN_PORT|What port the client should listen on|
|REMOTE_HOST|What address you want the server to reach|
|REMOTE_PORT|The port related to `REMOTE_HOST` to reach|
|SEND_LIMIT|Maximum number of messages to be sent by the bot|
|FILE_THRESHOLD|Maximum bytes of raw messages (anything more will be converted to file)|

> Note: using `CHUNK_SIZE` of more than 3072 will result in `ERROR: Message too large` from the API server

### server and client's built-in configuration

|Code|Value|
|---|---|
|`ZSTD_COMP = zstd.ZstdCompressor(level=19, write_content_size=True)`|The number `19` specifies the level of zlib compression, this number should be the same on both the client and the server|
|QUEUE_TTL|How long to keep messages in the queue before ignoring and removing them (in seconds)|
|BATCH_INTERVAL|How long to wait (in seconds) to batch multiple requests into one message. Increasing this will cause more latency and could cause your connection to drop, but it will increase the throughput|
|BATCH_MAX_BYTES|Maximum size of each batch. The number you set here will force the batch to flush out (be sent) when it reaches this limit|
|BATCH_BACKPRESSURE_LIMIT|Pause reading from source when the backpressure hits this limit|

Reducing `BATCH_BACKPRESSURE_LIMIT` will solve `CONNECTION CLOSED` messages. This limit will pause the server (or the client) from reading the data from the source of which the data is being generated from.