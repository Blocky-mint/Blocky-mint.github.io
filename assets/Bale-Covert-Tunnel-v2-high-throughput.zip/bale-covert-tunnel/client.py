# client.py

import asyncio
import json
import base64
import time
import uuid
import contextlib
import signal
import sys
import zstandard as zstd
import bale
from bale import InputFile
from typing import Optional, Tuple
from dataclasses import dataclass, field

from config import (
    BOT_B_TOKEN,
    SHARED_CHAT_ID,
    CHUNK_SIZE,
    LOCAL_LISTEN_HOST,
    LOCAL_LISTEN_PORT,
    REMOTE_HOST,
    REMOTE_PORT,
    SEND_LIMIT,
    FILE_THRESHOLD,
)

ZSTD_COMP = zstd.ZstdCompressor(level=2, write_content_size=True, threads=-1)
ZSTD_DECOMP = zstd.ZstdDecompressor()

QUEUE_TTL = 60.0
BATCH_INTERVAL = 0.7
BATCH_MAX_BYTES = 5 * 1024 * 1024
BATCH_BACKPRESSURE_LIMIT = 2 * 1024 * 1024

MAX_RETRIES = 5
INITIAL_RETRY_DELAY = 0.5
MAX_RETRY_DELAY = 30.0

@dataclass
class RetryState:
    attempts: int = 0
    last_success: float = field(default_factory=time.monotonic)
    consecutive_failures: int = 0
    
    def reset(self):
        self.attempts = 0
        self.consecutive_failures = 0
        self.last_success = time.monotonic()
    
    def backoff_delay(self) -> float:
        delay = min(INITIAL_RETRY_DELAY * (2 ** self.attempts), MAX_RETRY_DELAY)
        return delay

class TunnelClient:
    def __init__(self, token: str):
        self.prefix = "BOT_B"
        self.bot = bale.Bot(token)
        self.sessions = {}
        self.send_queue = asyncio.Queue()
        self.data_batch = []
        self.data_batch_lock = asyncio.Lock()
        self.rate_limit = SEND_LIMIT
        self.retry_state = RetryState()
        self.bot_healthy = True
        self.last_message_time = time.monotonic()
        self.adaptive_interval = BATCH_INTERVAL
        self.shutdown_event = asyncio.Event()
        self.running = True

    def setup_signal_handlers(self):
        """Setup graceful shutdown on SIGINT/SIGTERM"""
        def signal_handler(sig, frame):
            print(f"\n[B] Received signal {sig}, shutting down gracefully...")
            self.running = False
            self.shutdown_event.set()
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    async def on_before_ready(self):
        with contextlib.suppress(Exception):
            await self.bot.delete_webhook()
        print("[B] Ready")
        self.retry_state.reset()
        self.bot_healthy = True
        asyncio.create_task(self.send_loop())
        asyncio.create_task(self.batch_loop())
        asyncio.create_task(self.start_local_listener())
        asyncio.create_task(self.health_monitor())

    async def health_monitor(self):
        while self.running:
            try:
                await asyncio.wait_for(self.shutdown_event.wait(), timeout=30)
                break
            except asyncio.TimeoutError:
                age = time.monotonic() - self.last_message_time
                if age > 120 and self.retry_state.consecutive_failures > 3:
                    print(f"[B] Health check failed, attempting recovery...")
                    self.bot_healthy = False
                    await asyncio.sleep(5)
                    self.bot_healthy = True
                    self.retry_state.reset()

    async def send_with_retry(self, payload, max_retries=MAX_RETRIES):
        for attempt in range(max_retries):
            if not self.running:
                return False
            try:
                if isinstance(payload, tuple) and payload[0] == "FILE":
                    await self.send_as_file(payload[1])
                else:
                    await self.bot.send_message(SHARED_CHAT_ID, payload)
                
                self.retry_state.reset()
                self.last_message_time = time.monotonic()
                return True
                
            except Exception as e:
                self.retry_state.attempts = attempt + 1
                self.retry_state.consecutive_failures += 1
                
                if attempt < max_retries - 1:
                    delay = self.retry_state.backoff_delay()
                    print(f"[B] Send failed (attempt {attempt + 1}/{max_retries}), retrying in {delay:.1f}s: {e}")
                    await asyncio.sleep(delay)
                else:
                    print(f"[B] Send failed after {max_retries} attempts: {e}")
                    return False
        return False

    async def send_loop(self):
        while self.running:
            try:
                if not self.bot_healthy:
                    await asyncio.sleep(1)
                    continue
                
                try:
                    ts, payload = await asyncio.wait_for(self.send_queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                
                age = time.monotonic() - ts
                
                if age > QUEUE_TTL:
                    print(f"[B] Dropped stale message (age={age:.1f}s)")
                    continue
                
                success = await self.send_with_retry(payload)
                
                if not success and self.running:
                    if isinstance(payload, str) and ("OPEN" in payload or "CLOSE" in payload):
                        print("[B] Re-queuing critical control message")
                        await self.send_queue.put((time.monotonic(), payload))
                
                await asyncio.sleep(1 / self.rate_limit)
                
            except Exception as e:
                print(f"[B] send_loop error: {e}")
                await asyncio.sleep(1)

    async def batch_loop(self):
        while self.running:
            try:
                await asyncio.sleep(self.adaptive_interval)
                
                async with self.data_batch_lock:
                    if not self.data_batch:
                        self.adaptive_interval = min(self.adaptive_interval * 1.1, 0.5)
                        continue
                    
                    if len(self.data_batch) > 50:
                        self.adaptive_interval = max(self.adaptive_interval * 0.9, 0.05)
                    
                    batch, self.data_batch = self.data_batch, []

                groups = []
                current = []
                current_size = 0
                
                for item in batch:
                    item_size = len(item.get("payload", ""))
                    if current and current_size + item_size > BATCH_MAX_BYTES:
                        groups.append(current)
                        current = []
                        current_size = 0
                    current.append(item)
                    current_size += item_size
                
                if current:
                    groups.append(current)

                for group in groups:
                    if not self.running:
                        break
                    total_payload = sum(len(i.get("payload", "")) for i in group)
                    if total_payload >= FILE_THRESHOLD:
                        await self.send_queue.put((time.monotonic(), ("FILE", group)))
                    else:
                        msg = f"{self.prefix}:{json.dumps(group, separators=(',', ':'))}"
                        await self.send_queue.put((time.monotonic(), msg))
                        
            except Exception as e:
                print(f"[B] batch_loop error: {e}")
                await asyncio.sleep(0.5)

    async def send_as_file(self, group: list):
        try:
            data = json.dumps(group, separators=(',', ':')).encode("latin-1")
            input_file = InputFile(data, file_name="d")
            await self.bot.send_document(SHARED_CHAT_ID, input_file, caption="BOT_B_FILE")
        except Exception as e:
            print(f"[B] send_as_file error: {e}")
            raise

    async def enqueue_message(self, payload: dict):
        """Unified enqueue for all message types (OPEN, DATA, CLOSE)"""
        async with self.data_batch_lock:
            self.data_batch.append(payload)

    async def start_local_listener(self):
        restart_count = 0
        max_restarts = 5
        
        while self.running and restart_count < max_restarts:
            try:
                server = await asyncio.start_server(
                    self.handle_local_connection,
                    LOCAL_LISTEN_HOST,
                    LOCAL_LISTEN_PORT
                )
                print(f"[B] Listening on {LOCAL_LISTEN_HOST}:{LOCAL_LISTEN_PORT}")
                restart_count = 0
                
                async with server:
                    await self.shutdown_event.wait()
                    server.close()
                    await server.wait_closed()
                    break
                    
            except Exception as e:
                restart_count += 1
                if self.running and restart_count < max_restarts:
                    print(f"[B] Listener crashed: {e}, restarting ({restart_count}/{max_restarts})...")
                    await asyncio.sleep(5)
                else:
                    print(f"[B] Listener failed after {max_restarts} attempts or shutdown requested")
                    break

    async def handle_local_connection(self, reader, writer):
        if not self.running:
            writer.close()
            return
            
        session_id = uuid.uuid4().hex
        self.sessions[session_id] = (reader, writer)
        print(f"[B] New connection {session_id}")

        open_payload = {
            "session": session_id,
            "type": "OPEN",
            "host": REMOTE_HOST,
            "port": REMOTE_PORT,
        }
        await self.enqueue_message(open_payload)

        try:
            while self.running:
                while self.running:
                    async with self.data_batch_lock:
                        pending = sum(
                            len(i.get("payload", ""))
                            for i in self.data_batch
                            if i.get("session") == session_id
                        )
                    if pending < BATCH_BACKPRESSURE_LIMIT:
                        break
                    await asyncio.sleep(0.02)

                if not self.running:
                    break

                data = await asyncio.wait_for(reader.read(CHUNK_SIZE), timeout=300)
                if not data:
                    break
                
                compressed = ZSTD_COMP.compress(data)
                encoded = base64.b85encode(compressed).decode("ascii")
                await self.enqueue_message({
                    "session": session_id,
                    "type": "DATA",
                    "payload": encoded,
                })
                
        except asyncio.TimeoutError:
            print(f"[B] Read timeout ({session_id})")
        except Exception as e:
            if self.running:
                print(f"[B] Local read error ({session_id}): {e}")
        finally:
            await self.send_close(session_id)
            await self.close_session(session_id)

    async def on_message(self, message):
        if not self.running:
            return
            
        self.last_message_time = time.monotonic()
        text = getattr(message, "text", None)
        doc = getattr(message, "document", None)

        if doc is not None:
            caption = getattr(message, "caption", "") or ""
            if caption.startswith("BOT_A_FILE"):
                await self.handle_file_message(doc)
            return

        if not isinstance(text, str) or not text.startswith("BOT_A:"):
            return
        
        raw = text.split("BOT_A:", 1)[1].strip()
        await self.dispatch_raw(raw)

    async def handle_file_message(self, doc):
        for attempt in range(3):
            if not self.running:
                return
            try:
                raw = (await doc.get()).decode("latin-1")
                await self.dispatch_raw(raw)
                return
            except Exception as e:
                if attempt < 2 and self.running:
                    print(f"[B] File download failed (attempt {attempt + 1}/3), retrying: {e}")
                    await asyncio.sleep(1 * (attempt + 1))
                else:
                    print(f"[B] File download failed after 3 attempts: {e}")

    async def dispatch_raw(self, raw: str):
        try:
            parsed = json.loads(raw)
        except Exception as e:
            print(f"[B] Parse error: {e}")
            return
        
        items = parsed if isinstance(parsed, list) else [parsed]
        for item in items:
            if not self.running:
                break
            await self.handle_server_data(item)

    async def handle_server_data(self, payload: dict):
        session_id = payload.get("session")
        msg_type = payload.get("type")

        if session_id not in self.sessions:
            return

        _, writer = self.sessions[session_id]

        if msg_type == "DATA":
            try:
                compressed = base64.b85decode(payload["payload"])
                data = ZSTD_DECOMP.decompress(compressed)
                writer.write(data)
                await writer.drain()
            except (ConnectionResetError, BrokenPipeError, OSError):
                await self.close_session(session_id)
            except Exception as e:
                print(f"[B] DATA error: {e}")
                
        elif msg_type == "CLOSE":
            await self.close_session(session_id)
            print(f"[B] Session closed by remote {session_id}")

    async def send_close(self, session_id):
        close_payload = {"session": session_id, "type": "CLOSE"}
        await self.enqueue_message(close_payload)

    async def close_session(self, session_id):
        entry = self.sessions.pop(session_id, None)
        if entry is None:
            return
        _, writer = entry
        try:
            writer.close()
        except Exception:
            pass

    async def cleanup(self):
        """Cleanup all sessions on shutdown"""
        print("[B] Cleaning up sessions...")
        for session_id in list(self.sessions.keys()):
            await self.close_session(session_id)

    def register(self):
        @self.bot.listen("on_before_ready")
        async def _before_ready():
            await self.on_before_ready()

        @self.bot.listen("on_message")
        async def _on_message(msg):
            await self.on_message(msg)

    def run(self):
        self.setup_signal_handlers()
        self.register()
        
        restart_count = 0
        max_restarts = 3
        
        while self.running and restart_count < max_restarts:
            try:
                self.bot.run()
                break
            except KeyboardInterrupt:
                print("\n[B] Keyboard interrupt received")
                break
            except Exception as e:
                restart_count += 1
                if self.running and restart_count < max_restarts:
                    print(f"[B] Bot crashed: {e}, restarting ({restart_count}/{max_restarts})...")
                    time.sleep(5)
                else:
                    print(f"[B] Bot failed after {max_restarts} attempts or shutdown requested")
                    break
        
        print("[B] Shutting down...")
        self.running = False
        self.shutdown_event.set()
        
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self.cleanup())
                loop.run_until_complete(asyncio.sleep(2))
        except:
            pass
        
        print("[B] Shutdown complete")


if __name__ == "__main__":
    TunnelClient(BOT_B_TOKEN).run()
